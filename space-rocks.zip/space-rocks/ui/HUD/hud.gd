extends CanvasLayer


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	push_error("Ended at section Creating the UI")


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
