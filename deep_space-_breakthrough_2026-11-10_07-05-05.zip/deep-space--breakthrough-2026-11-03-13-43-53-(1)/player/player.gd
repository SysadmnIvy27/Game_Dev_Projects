class_name Player
extends CharacterBody3D


@export var current_speed = 5.0
@export var deceleration = 0.01
@export var mouse_sensivity = GameGlobals.mouse_sens
@export var lock_movement = false
@export var lock_interaction = false

@onready var neck = $neck
@onready var camera = $neck/Camera3D
@onready var chest_ray: RayCast3D = $ChestRay
@onready var step_ray: RayCast3D = $StepRay

const walk_speed = 5.0
const sprint_speed = 8.0
const jump_velocity = 4.5
const step_assist = 2.0
var drone : Node

func _enter_tree() -> void:
	set_multiplayer_authority(name.to_int())

func _ready() -> void:
	Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
	if !is_multiplayer_authority(): return
	camera.current = true

@rpc("call_local")
func _input(event: InputEvent) -> void:
	if !is_multiplayer_authority(): return
	if event is InputEventMouseMotion and GameGlobals.mouse_is_controling:
		rotate_y(deg_to_rad(-event.relative.x * mouse_sensivity))
		neck.rotate_x(deg_to_rad(-event.relative.y * mouse_sensivity))
		neck.rotation_degrees.x = clampf(neck.rotation_degrees.x,-90,90)

@rpc("call_local")
func get_input():
	if Input.is_action_just_pressed("swap") and drone != null:
		if drone.mode < len(drone.modes):
			drone.mode += 1
		else:
			drone.mode = 1
		if drone.mode == 3:
			drone.camera.make_current()
	if drone != null:
		if drone.mode == 3:
			drone.connected = true
			lock_movement = true
			lock_interaction = true
		else:
			camera.make_current()
			drone.connected = false
			lock_movement = false
			lock_interaction = false

@rpc("call_local")
func _physics_process(delta: float) -> void:
	if !is_multiplayer_authority(): return
	get_input()
	if lock_movement:
		set_process_input(false)
		return
	else:
		set_process_input(true)
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta
	if is_on_floor():
		velocity = Vector3.ZERO
	
	# Handle jump.
	if Input.is_action_just_pressed("jump") and is_on_floor() and not lock_movement:
		velocity.y = jump_velocity
	if not chest_ray.is_colliding() and step_ray.is_colliding() and Input.is_action_pressed("forward") and not lock_movement:
		position.y += 1
	if Input.is_action_pressed("sprint") and not lock_movement:
		current_speed = sprint_speed
	else:
		current_speed = walk_speed

	# Get the input direction and handle the movement/deceleration.
	if is_on_floor() and not lock_movement:
		var input_dir := Input.get_vector("left", "right", "forward", "backward")
		var direction := (transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()
		if direction:
			velocity.x = direction.x * current_speed
			velocity.z = direction.z * current_speed
		else:
			velocity.x = move_toward(velocity.x, 0, deceleration)
			velocity.z = move_toward(velocity.z, 0, deceleration)

	move_and_slide()
