extends Node3D

@export var Player_scene : PackedScene
#@onready var spawned_players: Node3D = $"."
@onready var player_spawn: Marker3D = $Spawn_Points/Player_spawn

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	if multiplayer.is_server():
		add_player(1)
		multiplayer.peer_connected.connect(add_player)
		multiplayer.peer_disconnected.connect(rem_player)


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	pass

func add_player(id):
	if !is_multiplayer_authority(): return
	var player : Node = Player_scene.instantiate()
	player.name = str(id)
	player.global_transform = player_spawn.global_transform
	add_child(player)
	print(player.global_transform)
	print(player_spawn.global_transform)
	
func rem_player(id):
	if !is_multiplayer_authority(): return
	print(id)
	for child in get_children():
		if child.name.to_int() == id:
			remove_child(child)
			child.queue_free()
