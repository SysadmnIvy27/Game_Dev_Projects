extends Control

@export var debug_level : PackedScene

signal start_game

var peer = ENetMultiplayerPeer.new()
var ip_address = "127.0.0.1"
var port = 42069

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_debug_level_pressed() -> void:
	peer.create_server(port)
	multiplayer.multiplayer_peer = peer
	start_game.emit(debug_level)

func _on_connect_pressed() -> void:
	peer.create_client(ip_address,port)
	multiplayer.multiplayer_peer = peer
	start_game.emit(debug_level)
