extends Node3D

const Player_scene : PackedScene = preload("res://player/player.tscn")
@onready var spawned_nodes: Node3D = $Spawned_Nodes
@onready var player_spawn: Marker3D = $Spawn_Points/Player_spawn

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	if multiplayer.is_server():
		add_player(1,player_spawn)
		multiplayer.peer_connected.connect(add_player)
		multiplayer.peer_disconnected.connect(rem_player)


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	pass

func add_player(id, marker : Marker3D = null):
	if marker == null:
		marker = player_spawn
	var player : CharacterBody3D = Player_scene.instantiate()
	player.name = str(id)
	player.player_id = id
	player.global_transform = marker.global_transform
	spawned_nodes.add_child(player)
	#print(player.global_transform)
	#print(player_spawn.global_transform)
	
func rem_player(id):
	if !is_multiplayer_authority(): return
	print("Removing player with id: ", id)
	for child in spawned_nodes.get_children():
		if child.name.to_int() == id:
			child.queue_free()
