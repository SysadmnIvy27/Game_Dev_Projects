extends RigidBody2D

@onready var hitbox = $CollisionShape2D
@onready var detection_range = $Detection_Range
@onready var Explosion_Range = $Explosion_Range
@onready var screensize = get_viewport_rect().size

@export var engine_power = 700.0
@export var turn_rate = 400.0
@export var turn_dampening = 100.0
@export var debug = false

var direction = 0
var tracked_entity : Node
var dmg = 4
var shield_dmg = 20


func _ready() -> void:
	set_process(false)

func start():
	await get_tree().create_timer(1.0).timeout # wait for missile to move away before tracking
	hitbox.disabled = false
	set_process(true)

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	if not tracked_entity or not tracked_entity.is_inside_tree():
		lock_target()
	else:
		var target_direction = (tracked_entity.global_position - global_position).normalized()
		var angle  = transform.x.angle_to(target_direction)
		var torque = (angle * turn_rate) - (angular_velocity * turn_dampening)
		apply_torque(torque)
		

func lock_target():
	var targets : Array
	for area in detection_range.get_overlapping_areas():
		if area.is_in_group("enemies"):
			targets.append(area)
	for body in detection_range.get_overlapping_bodies():
		if body.is_in_group("rocks"):
			targets.append(body)
	var closest_target : Node
	var target_dist : float
	closest_target = null
	target_dist = INF
	for target in targets:
		if target.is_in_group("enemies"):
			if global_position.distance_to(target.global_position) < target_dist:
				closest_target = target
				target_dist = global_position.distance_to(target.global_position)
	if closest_target == null:
		for target in targets:
			if target.is_in_group("rocks"):
				if global_position.distance_to(target.global_position) < target_dist:
					closest_target = target
					target_dist = global_position.distance_to(target.global_position)
	tracked_entity = closest_target

func _physics_process(_delta: float) -> void:
	constant_force = engine_power * transform.x
	#constant_torque = direction * turn_rate

func _integrate_forces(physics_state):
	var xform = physics_state.transform
	xform.origin.x = wrapf(xform.origin.x, 0, screensize.x)
	xform.origin.y = wrapf(xform.origin.y, 0, screensize.y)
	physics_state.transform = xform

func _on_burnout_timer_timeout() -> void:
	explode()
	
func explode():
	$Explosion_Sound.play()
	$CollisionShape2D.set_deferred("disabled", true)
	$Sprite2D.hide()
	$Explosion/AnimationPlayer.play("explosion")
	$Explosion.show()
	linear_velocity = Vector2.ZERO
	angular_velocity = 0
	await $Explosion/AnimationPlayer.animation_finished
	queue_free()

func _on_body_entered(_hitbody):
	for area in Explosion_Range.get_overlapping_areas():
		if area.is_in_group("enemies"):
			area.take_damage(dmg)
	for body in Explosion_Range.get_overlapping_bodies():
		if body.is_in_group("rocks"):
			body.explode()
		if body.name == "Player":
			body.shield -= shield_dmg
	explode()

func _on_explosion_range_area_entered(hitarea):
	if debug:
		print(hitarea.name)
		print(hitarea.get_groups())
	if not hitarea.is_in_group("enemies"):
		return
	else:
		linear_velocity = Vector2.ZERO
		angular_velocity = 0
		for area in Explosion_Range.get_overlapping_areas():
			if area.is_in_group("enemies"):
				area.take_damage(dmg)
		for body in Explosion_Range.get_overlapping_bodies():
			if body.is_in_group("rocks"):
				body.explode()
			if body.name == "Player":
				body.shield -= shield_dmg
		explode()
