extends RigidBody2D

@onready var Explosion_Range = $ExplosionRange
var screensize : Vector2
var dmg = 2
var shield_dmg = 70

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	screensize = get_viewport_rect().size

func _on_body_entered(body_entered):
	$AnimationPlayer.play("prime")
	await $AnimationPlayer.animation_finished
	for area in Explosion_Range.get_overlapping_areas():
		if area.is_in_group("enemies"):
			area.take_damage(dmg)
	for body in Explosion_Range.get_overlapping_bodies():
		if body.is_in_group("rocks"):
			body.explode()
		if body.name == "Player":
			body.shield -= shield_dmg
	explode()

func _integrate_forces(physics_state):
	var xform = physics_state.transform
	xform.origin.x = wrapf(xform.origin.x, 0, screensize.x)
	xform.origin.y = wrapf(xform.origin.y, 0, screensize.y)
	physics_state.transform = xform

func explode():
	$Explosion_Sound.play()
	$CollisionShape2D.set_deferred("disabled", true)
	Explosion_Range.set_deferred("disabled", true)
	$Sprite2D.hide()
	$Explosion/AnimationPlayer.play("explosion")
	$Explosion.show()
	linear_velocity = Vector2.ZERO
	angular_velocity = 0
	await $Explosion/AnimationPlayer.animation_finished
	queue_free()
