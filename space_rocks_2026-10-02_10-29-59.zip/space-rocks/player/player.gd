extends RigidBody2D
# exported vars
@export var engine_power = 500
@export var spin_power = 8000
@export var bullet_scene : PackedScene
@export var bomb_scene : PackedScene
@export var missile_scene : PackedScene
@export var fire_rate = 0.25
@export var max_shield = 100.0
@export var shield_regen = 5.0
@onready var bomb_bay: Marker2D = $BombBay
@onready var missile_rack_l: Marker2D = $MissileRackL
@onready var missile_rack_r: Marker2D = $MissileRackR
# vars
var thrust = Vector2.ZERO
var screensize = Vector2.ZERO
var rotation_dir = 0
enum {INIT, ALIVE, INVULNERABLE, DEAD}
var state = INIT
var can_shoot = true
var can_drop_bomb = true
var can_fire_missile = true
var missiles = 4: set = set_missiles
var reset_pos = false
var current_rack
var lives = 0: set = set_lives
var shield = 0: set = set_shield
# signals
signal lives_changed
signal dead
signal shield_changed
signal missiles_changed

# Called when the node enters the scene tree for the first time.
func _ready():
	screensize = get_viewport_rect().size
	$GunCooldown.wait_time = fire_rate
	change_state(ALIVE)
	current_rack = missile_rack_l
func change_state(new_state):
	match new_state:
		INIT:
			$CollisionShape2D.set_deferred("disabled",true)
			$Sprite2D.modulate.a = 0.5
		ALIVE:
			$CollisionShape2d.set_deferred("disabled",false)
			$Sprite2d.modulate.a = 1.0
		INVULNERABLE:
			$CollisionShape2d.set_deferred("disabled",true)
			$Sprite2d.modulate.a = 0.5
			$InvulnerabilityTimer.start()
		DEAD:
			$CollisionShape2d.set_deferred("disabled",true)
			$Sprite2d.hide()
			linear_velocity = Vector2.ZERO
			$EngineSound.stop()
			dead.emit()
	state = new_state
# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta):
	get_input()
	shield += shield_regen * delta
func get_input():
	$Exhaust.emitting = false
	thrust = Vector2.ZERO
	if state in [DEAD, INIT]:
		return
	if Input.is_action_pressed("thrust"):
		$Exhaust.emitting = true
		thrust = transform.x * engine_power
		if not $EngineSound.playing:
			$EngineSound.play()
	else:
		$EngineSound.stop()
	rotation_dir = Input.get_axis("rotate_left","rotate_right")
	if Input.is_action_pressed("shoot") and can_shoot:
		shoot()
	if Input.is_action_just_pressed("bomb") and can_drop_bomb:
		release_bomb()
	if Input.is_action_just_pressed("missiles") and can_fire_missile:
		fire_missiles()
func _integrate_forces(physics_state):
	var xform = physics_state.transform
	xform.origin.x = wrapf(xform.origin.x, 0, screensize.x)
	xform.origin.y = wrapf(xform.origin.y, 0, screensize.y)
	physics_state.transform = xform
	if reset_pos:
		physics_state.transform.origin = screensize / 2
		reset_pos = false
func _physics_process(_delta):
	if position.x > screensize.x:
		position.x = 0
	if position.x < 0:
		position.x = screensize.x
	if position.y > screensize.y:
		position.y = 0
	if position.y < 0:
		position.y = screensize.y
	constant_force = thrust
	constant_torque = rotation_dir * spin_power
func shoot():
	if state == INVULNERABLE:
		return
	can_shoot = false
	$LaserSound.play()
	$GunCooldown.start()
	var b = bullet_scene.instantiate()
	get_tree().root.add_child(b)
	b.start($Muzzle.global_transform)
func _on_gun_cooldown_timeout():
	can_shoot = true
func set_lives(value):
	lives = value
	lives_changed.emit(lives)
	shield = max_shield
	if lives <= 0:
		change_state(DEAD)
	else:
		change_state(INVULNERABLE)
func reset():
	reset_pos = true
	$Sprite2d.show()
	lives = 3
	change_state(ALIVE)
func _on_invulnerability_timer_timeout():
	change_state(ALIVE)
func _on_body_entered(body):
	if body.is_in_group("rocks"):
		shield -= body.size * 25
		body.explode()
func explode():
	$Explosion.show()
	$Explosion/AnimationPlayer.play("explosion")
	await $Explosion/AnimationPlayer.animation_finished
	$Explosion.hide()
func set_shield(value):
	value = min(value, max_shield)
	shield = value
	shield_changed.emit(shield / max_shield)
	if shield <= 0:
		lives -= 1
		explode()
func release_bomb():
	if state == INVULNERABLE:
		return
	var b = bomb_scene.instantiate()
	can_drop_bomb = false
	get_tree().root.add_child(b)
	b.linear_velocity = linear_velocity
	b.angular_velocity = angular_velocity
	b.global_position = bomb_bay.global_position
func fire_missiles():
	if state == INVULNERABLE or missiles - 1  < 0:
		return
	var m = missile_scene.instantiate()
	missiles -= 1
	can_fire_missile = false
	$MissileCooldown.start()
	if current_rack == missile_rack_l:
		current_rack = missile_rack_r
	elif current_rack == missile_rack_r:
		current_rack = missile_rack_l
	get_tree().root.add_child(m)
	m.global_transform = current_rack.global_transform
	m.start()
func _on_missile_cooldown_timeout() -> void:
	can_fire_missile = true
func set_missiles(value):
	missiles = value
	missiles_changed.emit(value)
