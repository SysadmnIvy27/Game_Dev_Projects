class_name PlayerInputSyncronizer
extends MultiplayerSynchronizer

@export var motion := Vector2()
@export var camera : Camera3D
@export var player : CharacterBody3D
@export var neck : Node3D
@export var shoulders : Node3D


#func _enter_tree() -> void:
#	set_multiplayer_authority(player.name.to_int())
	
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	if get_multiplayer_authority() == multiplayer.get_unique_id(): #
		camera.make_current()
		Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
	else:
		set_process(false)
		set_process_input(false)


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	motion = Input.get_vector("left", "right", "forward", "backward").normalized()
	
func _input(event: InputEvent) -> void:
	if event is InputEventMouseMotion:
		# mouse movement
		neck.rotate_x(deg_to_rad(-event.relative.y * GameGlobals.mouse_sens))
		print(get_node(^"..").name)
		get_node(^"..").rotate_y(deg_to_rad(-event.relative.x * GameGlobals.mouse_sens))
		neck.rotation_degrees.x = clampf(neck.rotation_degrees.x,-90,90)
		#neck.rotate_x(deg_to_rad(-event.relative.y * GameGlobals.mouse_sens))
		#neck.rotation_degrees.x = clampf(neck.rotation_degrees.x,-90,90)
