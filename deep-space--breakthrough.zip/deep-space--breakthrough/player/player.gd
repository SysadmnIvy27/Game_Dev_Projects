extends CharacterBody3D


@export var current_speed = 5.0
@export var deceleration = 0.01
@export var mouse_is_controling = true
@export var mouse_sensivity = 0.4

@onready var neck = $neck
@onready var chest_ray: RayCast3D = $ChestRay
@onready var step_ray: RayCast3D = $StepRay

const walk_speed = 5.0
const jump_velocity = 4.5
const step_assist = 2.0

func _ready() -> void:
	Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)

func _input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and mouse_is_controling:
		rotate_y(deg_to_rad(-event.relative.x * mouse_sensivity))
		neck.rotate_x(deg_to_rad(-event.relative.y * mouse_sensivity))
		neck.rotation_degrees.x = clampf(neck.rotation_degrees.x,-90,90)
		
func get_input():
	pass


func _physics_process(delta: float) -> void:
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta
	if is_on_floor():
		velocity = Vector3.ZERO
	
	if Input.is_action_just_pressed("escape"):
		mouse_is_controling = not mouse_is_controling
	if mouse_is_controling:
		Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
	else:
		Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)


	# Handle jump.
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = jump_velocity
	if not chest_ray.is_colliding() and step_ray.is_colliding() and Input.is_action_pressed("forward"):
		#velocity.y = step_assist
		position.y += 1

	# Get the input direction and handle the movement/deceleration.
	if is_on_floor():
		var input_dir := Input.get_vector("left", "right", "forward", "backward")
		var direction := (transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()
		if direction:
			velocity.x = direction.x * current_speed
			velocity.z = direction.z * current_speed
		else:
			velocity.x = move_toward(velocity.x, 0, deceleration)
			velocity.z = move_toward(velocity.z, 0, deceleration)

	move_and_slide()
