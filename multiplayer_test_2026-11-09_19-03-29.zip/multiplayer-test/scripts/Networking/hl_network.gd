extends Node

var peer : ENetMultiplayerPeer
var ip_address = "127.0.0.1"
var port = 42069

func start_server():
	peer = ENetMultiplayerPeer.new()
	peer.create_server(port)
	multiplayer.multiplayer_peer = peer
	
func start_client():
	peer = ENetMultiplayerPeer.new()
	peer.create_client(ip_address,port)
	multiplayer.multiplayer_peer = peer
