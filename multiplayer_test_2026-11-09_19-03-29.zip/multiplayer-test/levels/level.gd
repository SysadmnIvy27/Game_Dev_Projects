extends Node

@export var player: PackedScene


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	if multiplayer.is_server():
		add_player(1)
		multiplayer.peer_connected.connect(add_player)
		multiplayer.peer_disconnected.connect(remove_player)


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

func add_player(id : int):
	var new_player = player.instantiate()
	new_player.name = str(id)
	add_child(new_player)

func remove_player(id : int):
	print(id)
	for child in get_children():
		if child.name.to_int() == id:
			remove_child(child)
			child.queue_free()
