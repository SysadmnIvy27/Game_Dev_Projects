extends MultiplayerSpawner

@export var network_player: PackedScene

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	if multiplayer.is_server():
		spawn_player(1)
		multiplayer.peer_connected.connect(spawn_player)


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

func spawn_player(id: int):
	if !multiplayer.is_server(): return # ensures clients don't spawn players
	
	
	var player = network_player.instantiate()
	player.name = str(id)
	
	get_node(spawn_path).call_deferred("add_child", player)
