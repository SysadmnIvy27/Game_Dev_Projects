extends Node

@export var menu : PackedScene
@export var level : PackedScene

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	change_scene_to_packed(menu)


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass

func start_server(packscene):
	change_scene_to_packed(packscene)

func change_scene_to_packed(resource : PackedScene):
	var node : Node = resource.instantiate()
	for child in get_children():
		remove_child(child)
		child.queue_free()
	add_child(node)
	if node.has_signal(&"start_server"):
		node.start_server.connect(start_server)
