extends Control

signal start_server(level)

@export var level : PackedScene

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_server_pressed() -> void:
	HlNetwork.start_server()
	emit_signal("start_server", level)


func _on_client_pressed() -> void:
	HlNetwork.start_client()
	emit_signal("start_server", level)
